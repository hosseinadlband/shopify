

module.exports = {
    publicRuntimeConfig: {
        backendUrl: 'http://localhost:8000'
    }
}





