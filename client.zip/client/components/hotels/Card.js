


const Index = () => {
    return (
        <div className="col-lg-3">
            <div className="card">
                <div className="card-header">
                    هتل یک
                </div>
                <div className="card-body">
                    <img src="/hotels/img.png"
                         alt="test"
                        className="card-img-top"
                    />
                    <p className="mt-4 small">
                        هتل یک
                        هتل یک
                        هتل یک
                        هتل یک
                        هتل یک
                        هتل یک
                        هتل یک
                    </p>
                </div>
            </div>
        </div>

    )
}

export default Index